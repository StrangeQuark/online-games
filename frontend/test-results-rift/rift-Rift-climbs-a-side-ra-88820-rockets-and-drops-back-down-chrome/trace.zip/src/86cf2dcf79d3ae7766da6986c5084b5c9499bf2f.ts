import { expect, test, type Page } from "@playwright/test";
test.setTimeout(120_000);

async function value(page: Page, key: string) {
  return Number(
    await page.locator(".rift-stage canvas").getAttribute(`data-${key}`),
  );
}
async function advance(page: Page, ms: number) {
  await page.clock.runFor(ms);
}
test("Rift renders a 3D arena with jumping, free vertical aim and collectible weapons", async ({
  page,
}) => {
  test.setTimeout(90_000);
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.clock.install();
  await page.goto("/#/play/rift");
  await page.getByRole("button", { name: "Enter the arena" }).click();
  await advance(page, 100);
  await page.keyboard.down("Space");
  await advance(page, 300);
  expect(await value(page, "y")).toBeGreaterThan(1);
  await page.keyboard.up("Space");
  await advance(page, 600);
  expect(await value(page, "y")).toBe(0);
  await expect(page.locator("canvas")).toHaveAttribute("data-grounded", "true");
  await page.keyboard.down("ArrowUp");
  await advance(page, 350);
  await page.keyboard.up("ArrowUp");
  expect(await value(page, "pitch")).toBeGreaterThan(0.4);
  await page.keyboard.down("ArrowDown");
  await advance(page, 350);
  await page.keyboard.up("ArrowDown");
  await page.keyboard.down("KeyW");
  await advance(page, 580);
  await page.keyboard.up("KeyW");
  await expect(page.locator("canvas")).toHaveAttribute(
    "data-weapon",
    "shotgun",
  );
  await expect(page.locator(".rift-notice")).toContainText(
    "SCATTERGUN ACQUIRED",
  );
  await page.keyboard.down("KeyF");
  await advance(page, 500);
  await page.keyboard.up("KeyF");
  expect(await value(page, "shots")).toBeGreaterThan(0);
  await page.keyboard.press("KeyR");
  await advance(page, 100);
  await expect(page.locator(".rift-reload")).toContainText("RELOADING");
  await advance(page, 1900);
  await expect(page.locator(".rift-reload")).not.toBeVisible();
  await page.screenshot({
    path: "test-results/rift-foundry-floor.png",
    fullPage: true,
  });
  expect(errors).toEqual([]);
});

test("Rift climbs a side ramp, collects upper-floor rockets, and drops back down", async ({
  page,
}) => {
  await page.clock.install();
  await page.goto("/#/play/rift");
  await page.getByRole("button", { name: "Enter the arena" }).click();
  // Start in the south court, take the west ramp, then the upper rocket cache.
  await page.keyboard.down("KeyS");
  await advance(page, 500);
  await page.keyboard.up("KeyS");
  await page.keyboard.down("KeyA");
  await advance(page, 970);
  await page.keyboard.up("KeyA");
  await page.keyboard.down("KeyW");
  await advance(page, 3300);
  await page.keyboard.up("KeyW");
  expect(await value(page, "y")).toBeCloseTo(4.5, 1);
  await expect(page.locator("canvas")).toHaveAttribute("data-weapon", "rocket");
  await expect(page.locator(".rift-location")).toContainText("UPPER GALLERIES");
  await page.keyboard.down("ArrowRight");
  await advance(page, 500);
  await page.keyboard.up("ArrowRight");
  await page.screenshot({
    path: "test-results/rift-upper-gallery.png",
    fullPage: true,
  });
  await page.keyboard.down("ArrowLeft");
  await advance(page, 500);
  await page.keyboard.up("ArrowLeft");
  await page.keyboard.down("KeyD");
  await advance(page, 950);
  await page.keyboard.up("KeyD");
  await advance(page, 1000);
  expect(await value(page, "y")).toBeLessThan(0.1);
});

test("Rift central stairs lead to armor, and mouse capture aims both axes", async ({
  page,
}) => {
  await page.clock.install();
  await page.goto("/#/play/rift");
  await page.getByRole("button", { name: "Enter the arena" }).click();
  await page.keyboard.down("KeyS");
  await advance(page, 800);
  await page.keyboard.up("KeyS");
  await page.keyboard.down("KeyD");
  await advance(page, 1780);
  await page.keyboard.up("KeyD");
  await page.keyboard.down("KeyW");
  await advance(page, 2650);
  await page.keyboard.up("KeyW");
  expect(await value(page, "y")).toBeCloseTo(4.5, 1);
  await expect(page.locator(".rift-vitals")).toContainText("60");
  const canvas = page.locator(".rift-stage canvas"),
    bounds = (await canvas.boundingBox())!;
  await page.mouse.click(
    bounds.x + bounds.width / 2,
    bounds.y + bounds.height / 2,
  );
  await expect
    .poll(() => page.evaluate(() => document.pointerLockElement?.tagName))
    .toBe("CANVAS");
  const before = await value(page, "pitch");
  await page.mouse.move(
    bounds.x + bounds.width / 2 + 50,
    bounds.y + bounds.height / 2 - 45,
    { steps: 5 },
  );
  await advance(page, 100);
  expect(Math.abs((await value(page, "pitch")) - before)).toBeGreaterThan(0.04);
  expect(Math.abs(await value(page, "yaw"))).toBeGreaterThan(0.04);
  await page.keyboard.press("Escape");
  await expect
    .poll(() => page.evaluate(() => document.pointerLockElement))
    .toBeNull();
});

test("Rift touch movement, jump, look pad and firing work on a small screen", async ({
  browser,
  baseURL,
}) => {
  test.setTimeout(90_000);
  const context = await browser.newContext({
    baseURL,
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
  });
  const page = await context.newPage();
  try {
    const touch = await context.newCDPSession(page);
    const press = async (locator: import("@playwright/test").Locator) => {
      await locator.scrollIntoViewIfNeeded();
      const box = (await locator.boundingBox())!;
      const point = {
        x: box.x + box.width / 2,
        y: box.y + box.height / 2,
        id: 1,
      };
      await touch.send("Input.dispatchTouchEvent", {
        type: "touchStart",
        touchPoints: [point],
      });
      return point;
    };
    const release = () =>
      touch.send("Input.dispatchTouchEvent", {
        type: "touchEnd",
        touchPoints: [],
      });
    await page.clock.install();
    await page.goto("/#/play/rift");
    await page.getByRole("button", { name: "Enter the arena" }).click();
    await expect(page.locator(".rift-touch-controls")).toBeVisible();
    await press(page.getByRole("button", { name: "JUMP", exact: true }));
    await advance(page, 250);
    expect(await value(page, "y")).toBeGreaterThan(0.9);
    await release();
    await advance(page, 600);
    expect(await value(page, "y")).toBe(0);
    const point = await press(
      page.getByRole("application", { name: "Drag to look around" }),
    );
    await touch.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: [{ ...point, x: point.x + 35, y: point.y - 35 }],
    });
    await release();
    await advance(page, 100);
    expect(await value(page, "pitch")).toBeGreaterThan(0.25);
    expect(await value(page, "yaw")).toBeLessThan(-0.2);
    await press(page.getByRole("button", { name: "FIRE", exact: true }));
    await advance(page, 300);
    await release();
    expect(await value(page, "shots")).toBeGreaterThan(0);
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    await page.screenshot({
      path: "test-results/rift-mobile.png",
      fullPage: true,
    });
  } finally {
    await context.close();
  }
});
